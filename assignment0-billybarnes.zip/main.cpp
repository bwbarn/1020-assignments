#include <iostream>
using namespace std;


int main()
{
	cout << "Billy Barnes\n";
	return 0;
}


